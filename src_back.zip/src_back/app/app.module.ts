import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AdminMainComponent } from './admin-main/admin-main.component';
import { UserMainComponent } from './user-main/user-main.component';
import { UserTopMenuComponent } from './user-top-menu/user-top-menu.component';
import { AdminTopMenuComponent } from './admin-top-menu/admin-top-menu.component';
import { AdminLeftMenuComponent } from './admin-left-menu/admin-left-menu.component';
import { UserLeftMenuComponent } from './user-left-menu/user-left-menu.component';

//TABS
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatTabsModule} from '@angular/material/tabs';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HighchartsChartModule } from 'highcharts-angular';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    AdminMainComponent,
    UserMainComponent,
    UserTopMenuComponent,
    AdminTopMenuComponent,
    AdminLeftMenuComponent,
    UserLeftMenuComponent
        
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule,
    HighchartsChartModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
